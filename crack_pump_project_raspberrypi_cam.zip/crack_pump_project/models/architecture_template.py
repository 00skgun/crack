"""
config.yaml 의 model.type 이 'state_dict' 일 때만 필요합니다.
(torchscript 로 저장된 모델이라면 이 파일은 필요 없습니다.)

학습 시 사용했던 모델 클래스와 완전히 동일한 구조로 아래 build_model() 을 채운 뒤,
이 파일을 'architecture.py' 라는 이름으로 models/ 폴더에 저장하세요.
(model_loader.py 가 models.architecture 모듈을 import 합니다)
"""
import torch.nn as nn


def build_model(model_cfg: dict) -> nn.Module:
    """
    학습 때 사용한 모델과 동일하게 정의해야 state_dict 가 정상적으로 로드됩니다.
    아래는 예시이며, 실제 학습에 사용한 아키텍처로 반드시 교체하세요.
    """
    raise NotImplementedError(
        "models/architecture.py 의 build_model() 함수를 학습 시 사용한 "
        "실제 모델 아키텍처로 구현해 주세요. (예: U-Net, DeepLabV3 등)"
    )

    # 예시 1) torchvision 의 DeepLabV3 로 학습한 경우
    # from torchvision.models.segmentation import deeplabv3_resnet50
    # model = deeplabv3_resnet50(weights=None, num_classes=model_cfg.get("num_classes", 1))
    # return model

    # 예시 2) 직접 정의한 U-Net을 사용한 경우
    # from my_unet import UNet
    # model = UNet(in_channels=3, out_channels=model_cfg.get("num_classes", 1))
    # return model
