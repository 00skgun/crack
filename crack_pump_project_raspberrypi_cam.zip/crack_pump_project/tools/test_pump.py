"""펌프(GPIO) 배선 테스트: 지정한 핀을 2초간 켰다 끕니다.

사용법:
    python tools/test_pump.py [gpio_pin]
"""
import sys
import time

from gpiozero import OutputDevice


def main():
    pin = int(sys.argv[1]) if len(sys.argv) > 1 else 17
    device = OutputDevice(pin, active_high=True, initial_value=False)

    print(f"GPIO {pin} ON (2초간 유지)")
    device.on()
    time.sleep(2)
    device.off()
    print(f"GPIO {pin} OFF")

    device.close()


if __name__ == "__main__":
    main()
