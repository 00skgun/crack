"""모델 로드 + 이미지(또는 랜덤 이미지)로 추론 테스트.

사용법:
    python tools/test_model.py --config config.yaml
    python tools/test_model.py --config config.yaml --image sample_wall.jpg
"""
import argparse
import os
import sys

import cv2
import numpy as np
import yaml

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from crack_detector import CrackDetector
from model_loader import load_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--image", default=None, help="테스트할 이미지 경로 (없으면 랜덤 이미지 사용)")
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    model = load_model(cfg["model"])
    detector = CrackDetector(model, cfg["model"], cfg["detection"])

    if args.image:
        frame = cv2.imread(args.image)
        if frame is None:
            print(f"이미지를 읽을 수 없습니다: {args.image}")
            sys.exit(1)
    else:
        h, w = cfg["model"].get("input_size", [512, 512])
        frame = np.random.randint(0, 255, (h, w, 3), dtype=np.uint8)
        print("테스트 이미지가 지정되지 않아 랜덤 이미지로 파이프라인만 테스트합니다.")

    result = detector.detect(frame)
    print(f"crack_pixels     = {result['crack_pixels']}")
    print(f"area_ratio       = {result['area_ratio']:.4f}")
    print(f"frame_positive   = {result['frame_positive']}")

    overlay = detector.overlay_mask(frame, result["mask"])
    cv2.imwrite("model_test_overlay.jpg", overlay)
    print("model_test_overlay.jpg 에 결과 저장됨")


if __name__ == "__main__":
    main()
