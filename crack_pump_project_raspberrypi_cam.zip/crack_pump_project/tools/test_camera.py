"""라즈베리파이 카메라(또는 USB 카메라) 연결 테스트: 한 프레임을 캡처해 저장합니다.

사용법:
    python tools/test_camera.py                          # 기본값: picamera2 백엔드
    python tools/test_camera.py --backend usb --index 0   # USB 웹캠으로 테스트
"""
import argparse
import os
import sys

import cv2

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from camera import CameraError, create_camera


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", default="picamera2", choices=["picamera2", "usb"])
    parser.add_argument("--index", type=int, default=0, help="backend=usb 일 때 사용할 장치 번호")
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    args = parser.parse_args()

    cam_cfg = {
        "backend": args.backend,
        "device_index": args.index,
        "width": args.width,
        "height": args.height,
        "fps": 15,
    }

    try:
        cam = create_camera(cam_cfg)
    except CameraError as e:
        print(f"카메라 초기화 실패: {e}")
        sys.exit(1)

    ok, frame = cam.read()
    cam.close()

    if not ok or frame is None:
        print("프레임 캡처에 실패했습니다.")
        sys.exit(1)

    out_path = "camera_test.jpg"
    cv2.imwrite(out_path, frame)
    print(f"캡처 성공: {out_path} 에 저장됨 (해상도: {frame.shape[1]}x{frame.shape[0]}, backend={args.backend})")


if __name__ == "__main__":
    main()
