"""
gpiozero 를 이용한 미니 펌프(릴레이/트랜지스터 경유) 제어 모듈.

주의(하드웨어):
  라즈베리파이 GPIO 핀은 약 16mA 밖에 출력하지 못하므로
  펌프 모터를 절대 직접 구동할 수 없습니다.
  반드시 릴레이 모듈 또는 NPN 트랜지스터/MOSFET + 외부 전원(+ 플라이백 다이오드)을
  통해 펌프를 구동하고, GPIO 는 그 스위치를 켜고 끄는 신호로만 사용하세요.
  README.md 의 배선도를 참고하세요.
"""
import logging
import threading
import time

from gpiozero import OutputDevice

logger = logging.getLogger("crack_pump.pump_controller")


class PumpController:
    def __init__(self, pump_cfg: dict):
        self.pin = pump_cfg["gpio_pin"]
        self.active_high = pump_cfg.get("active_high", True)
        self.run_seconds = pump_cfg.get("run_seconds", 3.0)
        self.cooldown_seconds = pump_cfg.get("cooldown_seconds", 10.0)
        self.max_run_seconds = pump_cfg.get("max_run_seconds", 30.0)

        self._device = OutputDevice(
            self.pin, active_high=self.active_high, initial_value=False
        )
        self._lock = threading.Lock()
        self._last_finished_at = 0.0
        self._running = False
        self._off_timer = None

        logger.info(
            f"펌프 컨트롤러 초기화 완료 (GPIO {self.pin}, "
            f"active_high={self.active_high}, run={self.run_seconds}s, "
            f"cooldown={self.cooldown_seconds}s)"
        )

    def in_cooldown(self) -> bool:
        return (time.monotonic() - self._last_finished_at) < self.cooldown_seconds

    def trigger(self) -> bool:
        """균열 감지 확정 시 호출. 이미 동작 중이거나 쿨다운 중이면 무시하고 False 반환."""
        with self._lock:
            if self._running:
                logger.debug("펌프가 이미 동작 중이라 트리거를 무시합니다.")
                return False
            if self.in_cooldown():
                logger.debug("쿨다운 중이라 트리거를 무시합니다.")
                return False

            self._running = True
            self._device.on()
            logger.info(f"펌프 ON (최대 {self.run_seconds}초 동안 동작)")

            run_time = min(self.run_seconds, self.max_run_seconds)
            self._off_timer = threading.Timer(run_time, self._turn_off)
            self._off_timer.daemon = True
            self._off_timer.start()
            return True

    def _turn_off(self):
        with self._lock:
            self._device.off()
            self._running = False
            self._last_finished_at = time.monotonic()
            logger.info("펌프 OFF")

    def emergency_stop(self):
        """비상 정지: 타이머와 무관하게 즉시 펌프를 끕니다."""
        with self._lock:
            if self._off_timer is not None:
                self._off_timer.cancel()
            self._device.off()
            self._running = False
            self._last_finished_at = time.monotonic()
            logger.warning("펌프 비상 정지 실행")

    def close(self):
        self.emergency_stop()
        self._device.close()
