"""
라즈베리파이 카메라(CSI, picamera2)로 벽면을 촬영하며 균열 분할 모델로
실시간 추론을 수행하고, 균열이 감지되면 미니 펌프를 동작시키는 메인 실행 스크립트.
(config.yaml 의 camera.backend 를 "usb" 로 바꾸면 USB 웹캠도 사용 가능)

실행:
    python src/main.py --config config.yaml
    python src/main.py --config config.yaml --show   (모니터 연결 시 미리보기)
"""
import argparse
import logging
import os
import signal
import sys
import time
from datetime import datetime

import cv2
import yaml

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from camera import CameraError, create_camera
from crack_detector import CrackDetector
from model_loader import ModelLoadError, load_model
from pump_controller import PumpController


def setup_logging(log_cfg: dict):
    level = getattr(logging, log_cfg.get("log_level", "INFO").upper(), logging.INFO)
    handlers = [logging.StreamHandler()]
    log_file = log_cfg.get("log_file")
    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=handlers,
    )


def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


class GracefulShutdown:
    def __init__(self):
        self.should_stop = False
        signal.signal(signal.SIGINT, self._handle)
        signal.signal(signal.SIGTERM, self._handle)

    def _handle(self, signum, frame):
        self.should_stop = True


def main():
    parser = argparse.ArgumentParser(description="균열 감지 + 펌프 제어 시스템")
    parser.add_argument("--config", default="config.yaml", help="설정 파일 경로")
    parser.add_argument("--show", action="store_true", help="화면에 미리보기 표시 (모니터 연결 시)")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg["logging"])
    logger = logging.getLogger("crack_pump.main")

    out_dir = cfg["logging"].get("output_dir", "detections")
    if cfg["logging"].get("save_detections", True):
        os.makedirs(out_dir, exist_ok=True)

    logger.info("=== 균열 감지 & 펌프 제어 시스템 시작 ===")

    try:
        model = load_model(cfg["model"])
    except ModelLoadError as e:
        logger.error(f"모델 로드 실패: {e}")
        sys.exit(1)

    detector = CrackDetector(model, cfg["model"], cfg["detection"])
    pump = PumpController(cfg["pump"])

    cam_cfg = cfg["camera"]
    try:
        cam = create_camera(cam_cfg)
    except CameraError as e:
        logger.error(f"카메라 초기화 실패: {e}")
        pump.close()
        sys.exit(1)

    shutdown = GracefulShutdown()
    frame_interval = 1.0 / max(cam_cfg.get("fps", 15), 1)

    try:
        while not shutdown.should_stop:
            loop_start = time.monotonic()
            ok, frame = cam.read()
            if not ok or frame is None:
                logger.warning("프레임을 읽지 못했습니다. 재시도합니다.")
                time.sleep(0.5)
                continue

            result = detector.detect(frame)
            logger.debug(
                f"crack_pixels={result['crack_pixels']} "
                f"area_ratio={result['area_ratio']:.4f} "
                f"streak={result['streak']}"
            )

            if result["confirmed"]:
                triggered = pump.trigger()
                if triggered:
                    logger.info(
                        f"균열 감지 확정! area_ratio={result['area_ratio']:.4f} -> 펌프 동작"
                    )
                    if cfg["logging"].get("save_detections", True):
                        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                        overlay = detector.overlay_mask(frame, result["mask"])
                        cv2.imwrite(os.path.join(out_dir, f"crack_{ts}.jpg"), overlay)

            if args.show:
                overlay = detector.overlay_mask(frame, result["mask"])
                cv2.imshow("Crack Detection", overlay)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

            elapsed = time.monotonic() - loop_start
            sleep_time = frame_interval - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)

    finally:
        logger.info("종료 처리 중...")
        cam.close()
        if args.show:
            cv2.destroyAllWindows()
        pump.close()
        logger.info("=== 시스템 종료 ===")


if __name__ == "__main__":
    main()
