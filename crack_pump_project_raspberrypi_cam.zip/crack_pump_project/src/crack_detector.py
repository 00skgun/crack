"""
카메라 프레임을 받아 전처리 -> 모델 추론 -> 후처리를 수행해
균열 여부와 분할 마스크를 반환하는 모듈.
"""
import logging

import cv2
import numpy as np
import torch

logger = logging.getLogger("crack_pump.crack_detector")


class CrackDetector:
    def __init__(self, model: torch.nn.Module, model_cfg: dict, det_cfg: dict):
        self.model = model
        self.device = torch.device(model_cfg.get("device", "cpu"))
        self.input_h, self.input_w = model_cfg.get("input_size", [512, 512])
        self.mean = np.array(model_cfg.get("mean", [0.485, 0.456, 0.406]), dtype=np.float32)
        self.std = np.array(model_cfg.get("std", [0.229, 0.224, 0.225]), dtype=np.float32)
        self.num_classes = model_cfg.get("num_classes", 1)

        self.prob_threshold = det_cfg.get("prob_threshold", 0.5)
        self.area_ratio_threshold = det_cfg.get("area_ratio_threshold", 0.002)
        self.min_pixel_count = det_cfg.get("min_pixel_count", 150)
        self.consecutive_frames = det_cfg.get("consecutive_frames", 3)

        self._positive_streak = 0

    def preprocess(self, frame_bgr: np.ndarray) -> torch.Tensor:
        img = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (self.input_w, self.input_h), interpolation=cv2.INTER_LINEAR)
        img = img.astype(np.float32) / 255.0
        img = (img - self.mean) / self.std
        tensor = torch.from_numpy(img.transpose(2, 0, 1)).unsqueeze(0).float()
        return tensor.to(self.device)

    @torch.no_grad()
    def infer(self, frame_bgr: np.ndarray):
        tensor = self.preprocess(frame_bgr)
        output = self.model(tensor)

        # 일부 모델은 튜플/딕셔너리를 반환하므로 정리
        if isinstance(output, (tuple, list)):
            output = output[0]
        if isinstance(output, dict):
            output = output.get("out", next(iter(output.values())))

        if self.num_classes == 1:
            prob = torch.sigmoid(output)[0, 0]
        else:
            prob = torch.softmax(output, dim=1)[0, 1]  # 클래스 1 = 균열이라고 가정

        mask = (prob >= self.prob_threshold).byte().cpu().numpy()
        prob_np = prob.cpu().numpy()
        return mask, prob_np

    def detect(self, frame_bgr: np.ndarray) -> dict:
        mask, prob_np = self.infer(frame_bgr)

        crack_pixels = int(mask.sum())
        total_pixels = mask.shape[0] * mask.shape[1]
        area_ratio = crack_pixels / total_pixels

        frame_positive = (
            crack_pixels >= self.min_pixel_count
            and area_ratio >= self.area_ratio_threshold
        )

        if frame_positive:
            self._positive_streak += 1
        else:
            self._positive_streak = 0

        confirmed = self._positive_streak >= self.consecutive_frames

        return {
            "mask": mask,
            "prob": prob_np,
            "crack_pixels": crack_pixels,
            "area_ratio": area_ratio,
            "frame_positive": frame_positive,
            "streak": self._positive_streak,
            "confirmed": confirmed,
        }

    @staticmethod
    def overlay_mask(frame_bgr: np.ndarray, mask: np.ndarray, color=(0, 0, 255), alpha=0.5) -> np.ndarray:
        h, w = frame_bgr.shape[:2]
        mask_resized = cv2.resize(mask.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST)
        overlay = frame_bgr.copy()
        overlay[mask_resized > 0] = color
        return cv2.addWeighted(overlay, alpha, frame_bgr, 1 - alpha, 0)
