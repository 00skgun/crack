"""
esw_seg_model_best.pt 모델을 로드하는 모듈.

모델 저장 방식에 따라 아래 세 가지 방식 중 하나로 로드합니다.
config.yaml 의 model.type 값으로 방식을 지정합니다.

  - torchscript : torch.jit.script/trace 로 저장된 모델 (권장, 가장 안전하고 빠름)
  - full_model  : torch.save(model, path) 로 모델 객체 전체를 저장한 경우
  - state_dict  : torch.save(model.state_dict(), path) 로 가중치만 저장한 경우
                  (models/architecture.py 에 학습 때 사용한 것과 동일한
                   모델 클래스를 정의해 두어야 합니다. models/architecture_template.py 참고)
"""
import logging

import torch

logger = logging.getLogger("crack_pump.model_loader")


class ModelLoadError(RuntimeError):
    pass


def load_model(model_cfg: dict) -> torch.nn.Module:
    path = model_cfg["path"]
    model_type = model_cfg.get("type", "torchscript")
    device = torch.device(model_cfg.get("device", "cpu"))

    logger.info(f"모델 로드 시작: {path} (type={model_type}, device={device})")

    if model_type == "torchscript":
        try:
            model = torch.jit.load(path, map_location=device)
        except Exception as e:
            raise ModelLoadError(
                f"TorchScript 모델 로드 실패: {e}\n"
                "모델이 torch.jit.save() 로 저장된 것이 맞는지 확인하거나, "
                "config.yaml 의 model.type 을 'full_model' 또는 'state_dict' 로 바꿔보세요."
            ) from e

    elif model_type == "full_model":
        try:
            model = torch.load(path, map_location=device, weights_only=False)
        except Exception as e:
            raise ModelLoadError(f"전체 모델 객체 로드 실패: {e}") from e
        if not isinstance(model, torch.nn.Module):
            raise ModelLoadError(
                f"{path} 에 저장된 객체가 nn.Module 이 아닙니다 (state_dict 일 가능성이 높습니다). "
                "config.yaml 의 model.type 을 'state_dict' 로 바꿔보세요."
            )

    elif model_type == "state_dict":
        try:
            from models.architecture import build_model
        except ImportError as e:
            raise ModelLoadError(
                "model.type 이 'state_dict' 인 경우 models/architecture.py 안에 "
                "학습 때 사용한 모델 클래스와 build_model() 함수를 정의해야 합니다. "
                "models/architecture_template.py 를 참고해서 작성한 뒤 "
                "architecture.py 로 저장해 주세요."
            ) from e
        model = build_model(model_cfg)
        state_dict = torch.load(path, map_location=device, weights_only=True)
        # 흔한 접두어(module., model. 등) 정리
        cleaned = {}
        for k, v in state_dict.items():
            new_k = k
            for prefix in ("module.", "model."):
                if new_k.startswith(prefix):
                    new_k = new_k[len(prefix):]
            cleaned[new_k] = v
        missing, unexpected = model.load_state_dict(cleaned, strict=False)
        if missing:
            logger.warning(f"로드되지 않은 파라미터: {missing}")
        if unexpected:
            logger.warning(f"사용되지 않은 파라미터: {unexpected}")

    else:
        raise ModelLoadError(f"알 수 없는 model.type: {model_type}")

    model.to(device)
    model.eval()
    logger.info("모델 로드 완료")
    return model
