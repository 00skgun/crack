"""
카메라 입력 추상화 모듈.

config.yaml 의 camera.backend 값에 따라
  - "picamera2" : 라즈베리파이 카메라 모듈 (CSI 리본 케이블, picamera2 라이브러리)
  - "usb"       : USB 웹캠 (OpenCV VideoCapture)
중 하나를 사용합니다.

두 백엔드 모두 OpenCV와 동일하게 BGR 순서의 numpy 배열 (H, W, 3) 을 반환하므로
crack_detector.py 이후의 파이프라인은 백엔드에 상관없이 동일하게 동작합니다.
"""
import logging

logger = logging.getLogger("crack_pump.camera")


class CameraError(RuntimeError):
    pass


class BaseCamera:
    def read(self):
        """(성공여부: bool, frame: np.ndarray|None) 를 반환합니다."""
        raise NotImplementedError

    def close(self):
        raise NotImplementedError


class PiCamera(BaseCamera):
    """라즈베리파이 카메라 모듈 (CSI, picamera2 라이브러리 사용)."""

    def __init__(self, cam_cfg: dict):
        try:
            from picamera2 import Picamera2
        except ImportError as e:
            raise CameraError(
                "picamera2 모듈을 찾을 수 없습니다.\n"
                "라즈베리파이 OS에서 아래 명령으로 설치하세요 (pip이 아닌 apt 설치입니다):\n"
                "  sudo apt update && sudo apt install -y python3-picamera2\n"
                "가상환경(venv)을 사용 중이라면 --system-site-packages 옵션으로 "
                "다시 만들어야 시스템에 설치된 picamera2를 인식합니다. "
                "자세한 내용은 README.md 3장을 참고하세요."
            ) from e

        width = cam_cfg.get("width", 640)
        height = cam_cfg.get("height", 480)
        fps = cam_cfg.get("fps", 15)

        self._picam2 = Picamera2()
        video_config = self._picam2.create_video_configuration(
            main={"size": (width, height), "format": "BGR888"}
        )
        self._picam2.configure(video_config)

        try:
            frame_duration_us = int(1_000_000 / fps)
            self._picam2.set_controls(
                {"FrameDurationLimits": (frame_duration_us, frame_duration_us)}
            )
        except Exception:
            logger.warning("FPS(FrameDurationLimits) 설정에 실패했습니다. 기본값으로 진행합니다.")

        self._picam2.start()
        logger.info(f"라즈베리파이 카메라 시작 (해상도 {width}x{height}, 목표 fps={fps})")

    def read(self):
        # format="BGR888" 로 설정했으므로 OpenCV와 동일한 BGR 순서 배열이 반환됩니다.
        frame = self._picam2.capture_array()
        return True, frame

    def close(self):
        try:
            self._picam2.stop()
            self._picam2.close()
        except Exception:
            pass
        logger.info("라즈베리파이 카메라 종료")


class USBCamera(BaseCamera):
    """USB 웹캠 (OpenCV VideoCapture 사용). 개발 PC에서 테스트할 때 유용합니다."""

    def __init__(self, cam_cfg: dict):
        import cv2

        index = cam_cfg.get("device_index", 0)
        self._cap = cv2.VideoCapture(index)
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, cam_cfg.get("width", 640))
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, cam_cfg.get("height", 480))
        self._cap.set(cv2.CAP_PROP_FPS, cam_cfg.get("fps", 15))

        if not self._cap.isOpened():
            raise CameraError(
                f"USB 카메라(index={index})를 열 수 없습니다. 연결 상태와 장치 번호를 확인하세요."
            )
        logger.info(f"USB 카메라 시작 (index={index})")

    def read(self):
        return self._cap.read()

    def close(self):
        self._cap.release()
        logger.info("USB 카메라 종료")


def create_camera(cam_cfg: dict) -> BaseCamera:
    backend = cam_cfg.get("backend", "picamera2")
    if backend == "picamera2":
        return PiCamera(cam_cfg)
    elif backend == "usb":
        return USBCamera(cam_cfg)
    else:
        raise CameraError(f"알 수 없는 camera.backend: {backend} ('picamera2' 또는 'usb' 중 선택)")
