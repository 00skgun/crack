# 벽면 균열 감지 → 자동 펌프 제어 시스템

라즈베리파이 + 라즈베리파이 카메라 모듈(CSI) + PyTorch 균열 분할(segmentation) 모델을
이용해 벽면을 실시간으로 촬영하고, 균열이 검출되면 GPIO에 연결된 미니 펌프를
자동으로 동작시키는 프로젝트입니다.

기본 카메라 백엔드는 라즈베리파이 카메라 모듈(picamera2)이며, 설정 한 줄만 바꾸면
USB 웹캠으로도 전환할 수 있습니다 (개발 PC에서 미리 테스트할 때 유용).

---

## 1. 폴더 구조

```
crack_pump_project/
├── config.yaml                  # 모든 설정 (카메라/모델/판정 임계값/펌프)
├── requirements.txt
├── models/
│   ├── esw_seg_model_best.pt    # ← 사용자의 학습된 모델을 여기에 넣으세요
│   └── architecture_template.py # state_dict 저장 방식일 때만 필요
├── src/
│   ├── camera.py                 # 카메라 입력 추상화 (picamera2 CSI / USB 선택)
│   ├── model_loader.py          # 모델 로드 (torchscript/full_model/state_dict)
│   ├── crack_detector.py        # 전처리 → 추론 → 균열 판정 로직
│   ├── pump_controller.py       # GPIO 펌프 제어 (gpiozero)
│   └── main.py                  # 전체 파이프라인 실행 (메인 실행 파일)
├── tools/
│   ├── test_camera.py           # 카메라 연결 단독 테스트 (picamera2/usb)
│   ├── test_pump.py             # 펌프 GPIO 배선 단독 테스트
│   └── test_model.py            # 모델 로드/추론 단독 테스트
└── systemd/
    └── crack-pump.service       # 부팅 시 자동 실행용 systemd 서비스
```

---

## 2. 카메라 모듈(CSI) 연결

1. 라즈베리파이 전원을 끈 상태에서 진행하세요.
2. 보드의 **CSI 카메라 커넥터**(라즈베리파이 4/3B+ 등은 이더넷 포트 옆, Zero 계열은 별도 소형 커넥터)의
   플라스틱 클립을 위로 살짝 당겨 엽니다.
3. 리본 케이블을 삽입합니다. **금속 접점(파란색 면 반대쪽)이 이더넷/USB 포트를 향하도록** 꽂는 것이 일반적이지만,
   보드 종류(표준형/Zero형)에 따라 커넥터 방향이 다르므로 케이블에 인쇄된 화살표나 카메라 모듈 설명서를 반드시 확인하세요.
4. 클립을 눌러 케이블을 고정합니다. 헐겁게 꽂히면 초록/보라 줄무늬 화면이나 "카메라를 찾을 수 없음" 오류가 발생합니다.
5. 전원을 켠 뒤, 카메라 인터페이스를 활성화합니다.
   - **Raspberry Pi OS Bookworm(최신)**: libcamera 기반으로 대부분 별도 설정 없이 자동 인식됩니다.
   - **이전 버전(Bullseye 이하)**: `sudo raspi-config` → `Interface Options` → `Camera` → `Enable` 후 재부팅하세요.
6. 아래 명령으로 카메라가 인식되는지 확인합니다.

```bash
# Bookworm 이상
rpicam-hello --list-cameras

# Bullseye 이하
libcamera-hello --list-cameras
```

카메라 모델명이 출력되면 연결이 정상입니다.

---

## 3. 펌프 배선 (★ 중요 ★)

**라즈베리파이 GPIO 핀은 최대 약 16mA밖에 출력하지 못하기 때문에
미니 펌프(모터)를 절대로 GPIO에 직접 연결하면 안 됩니다.**
GPIO는 스위치를 켜고 끄는 "신호"로만 사용하고, 실제 펌프 전원은
릴레이 모듈 또는 트랜지스터/MOSFET을 통해 별도 전원(펌프 정격 전압)으로 공급해야 합니다.

### 방법 A. 릴레이 모듈 사용 (가장 간단, 추천)

```
라즈베리파이 GPIO17 ── IN  (릴레이 모듈)
라즈베리파이 5V      ── VCC (릴레이 모듈)
라즈베리파이 GND     ── GND (릴레이 모듈)

펌프(+) ── 릴레이 COM
릴레이 NO ── 외부 전원(+)  (펌프 정격 전압, 예: 5V/12V 어댑터)
펌프(-) ── 외부 전원(-)
```

### 방법 B. NPN 트랜지스터/MOSFET 사용

```
GPIO17 ── 저항(1kΩ) ── 트랜지스터 베이스(B)
펌프(+) ── 외부 전원(+)
펌프(-) ── 트랜지스터 컬렉터(C)
트랜지스터 이미터(E) ── GND (라즈베리파이 GND와 공통)
펌프와 병렬로 다이오드(1N4007 등)를 역방향으로 연결 (역기전력 보호)
```

> config.yaml 의 `pump.gpio_pin` 을 실제 연결한 BCM 핀 번호로 맞춰주세요.
> 릴레이가 LOW 신호에서 켜지는 "액티브 로우" 타입이라면 `pump.active_high: false` 로 설정하세요.

---

## 4. 소프트웨어 설치 (라즈베리파이에서)

권장 환경: Raspberry Pi OS **64bit**, Python 3.9 이상

```bash
# 1) picamera2 및 필수 시스템 라이브러리 설치 (apt, 최신 Raspberry Pi OS는 기본 포함되어 있을 수 있음)
sudo apt update
sudo apt install -y python3-picamera2 libatlas-base-dev libjpeg-dev libopenjp2-7 libtiff5

# 2) 프로젝트 폴더로 이동
cd crack_pump_project

# 3) 가상환경 생성 (--system-site-packages 필수: apt로 설치한 picamera2를 venv에서도 사용하기 위함)
python3 -m venv venv --system-site-packages
source venv/bin/activate

# 4) pip 업그레이드
pip install --upgrade pip

# 5) 나머지 의존성 설치
#    torch/torchvision은 PyPI 기본 wheel이 라즈베리파이(ARM)에서 느리거나 없을 수 있으므로
#    piwheels 인덱스를 사용하는 것을 권장합니다.
pip install -r requirements.txt --extra-index-url https://www.piwheels.org/simple
```

> **주의**: `python3-picamera2` 는 `pip install picamera2` 로 설치하지 마세요. libcamera 시스템
> 라이브러리와 긴밀히 연동되어 있어 apt로 설치해야 정상 동작합니다. (requirements.txt에도 포함되어 있지 않습니다)

설치 후 아래 명령으로 picamera2가 venv 안에서도 보이는지 확인하세요.

```bash
python3 -c "from picamera2 import Picamera2; print('picamera2 OK')"
```

---

## 5. 모델 파일 준비

1. 학습된 `esw_seg_model_best.pt` 파일을 `models/` 폴더에 넣습니다.
2. `config.yaml` 의 `model.type` 을 실제 저장 방식에 맞게 설정합니다.

| 저장 방식 | model.type | 설명 |
|---|---|---|
| `torch.jit.save(model, path)` | `torchscript` | 권장. 모델 클래스 정의 없이 바로 로드됨 |
| `torch.save(model, path)` | `full_model` | 모델 객체 전체 저장 (pickle) |
| `torch.save(model.state_dict(), path)` | `state_dict` | 가중치만 저장. `models/architecture_template.py` 를 참고해 `models/architecture.py` 에 학습 때 사용한 모델 클래스를 그대로 정의해야 함 |

3. `config.yaml` 의 `model.input_size`, `model.mean/std`, `model.num_classes` 를
   **학습 시 사용한 값과 동일하게** 맞춰주세요. (이 값이 다르면 정확도가 크게 떨어집니다)

---

## 6. 단계별 테스트 (전체 실행 전에 하나씩 확인하세요)

```bash
# 1) 라즈베리파이 카메라가 잘 열리는지 확인 (기본값: picamera2)
python tools/test_camera.py
# USB 웹캠으로 테스트하려면:
# python tools/test_camera.py --backend usb --index 0

# 2) 펌프 배선이 맞는지 확인 (2초간 켜짐)
python tools/test_pump.py 17

# 3) 모델이 잘 로드되고 추론이 되는지 확인
python tools/test_model.py --config config.yaml --image sample_wall.jpg
```

세 가지가 모두 정상이면 전체 시스템을 실행합니다.

---

## 7. 전체 시스템 실행

```bash
# 헤드리스(모니터 없이) 실행
python src/main.py --config config.yaml

# 모니터 연결 시 미리보기 창과 함께 실행 (q 키로 종료)
python src/main.py --config config.yaml --show
```

- 균열이 `detection.consecutive_frames` 프레임 연속으로 감지되면 "확정"으로 판단하고 펌프를 동작시킵니다. (단발성 오탐 방지)
- 감지 시점의 오버레이 이미지는 `detections/` 폴더에 저장됩니다 (`logging.save_detections: true`).
- 로그는 `crack_pump.log` 에 남습니다.
- USB 웹캠으로 전환하려면 `config.yaml` 의 `camera.backend` 를 `usb` 로 바꾸고 `camera.device_index` 를 설정하세요.

---

## 8. 부팅 시 자동 실행 설정 (선택)

```bash
sudo cp systemd/crack-pump.service /etc/systemd/system/
sudo nano /etc/systemd/system/crack-pump.service   # 경로(User, WorkingDirectory 등)를 실제 환경에 맞게 수정

sudo systemctl daemon-reload
sudo systemctl enable crack-pump.service
sudo systemctl start crack-pump.service

# 상태 확인
sudo systemctl status crack-pump.service
journalctl -u crack-pump.service -f
```

> systemd 서비스에서 picamera2를 사용하려면 `venv` 를 `--system-site-packages` 옵션으로 만들었는지,
> 그리고 서비스의 `User` 가 `video` 그룹에 속해 있는지 확인하세요 (`sudo usermod -aG video pi`).

---

## 9. config.yaml 주요 옵션 설명

| 옵션 | 설명 |
|---|---|
| `camera.backend` | `picamera2`(기본, CSI 카메라) 또는 `usb`(USB 웹캠) |
| `detection.prob_threshold` | 픽셀 단위로 "균열"로 판단할 확률 임계값 (모델 출력 기준) |
| `detection.area_ratio_threshold` | 전체 프레임 대비 균열 픽셀 비율이 이 값 이상이어야 감지로 인정 |
| `detection.min_pixel_count` | 최소 균열 픽셀 수 (너무 작은 노이즈성 검출 무시) |
| `detection.consecutive_frames` | 이 프레임 수만큼 연속으로 검출돼야 "확정"으로 처리 (오탐 방지) |
| `pump.run_seconds` | 펌프 1회 동작 시간 |
| `pump.cooldown_seconds` | 펌프 동작 종료 후 다음 트리거까지 대기 시간 (과다 분사 방지) |
| `pump.max_run_seconds` | 안전을 위한 최대 연속 동작 시간 (로직 오류 시 무한 동작 방지) |

카메라가 흔들리거나 조명 변화가 심하면 `area_ratio_threshold`, `min_pixel_count`,
`consecutive_frames` 값을 높여 오탐을 줄일 수 있습니다.

---

## 10. 문제 해결

- **카메라가 인식되지 않음**: `rpicam-hello --list-cameras`(또는 `libcamera-hello --list-cameras`)로 하드웨어 인식 여부 먼저 확인 → 리본 케이블 방향과 고정 상태 재점검 → `raspi-config` 에서 카메라 인터페이스가 활성화되어 있는지 확인.
- **`ImportError: picamera2 모듈을 찾을 수 없습니다`**: `sudo apt install -y python3-picamera2` 설치 여부와, venv를 `--system-site-packages` 옵션으로 만들었는지 확인하세요.
- **화면이 초록/보라색 줄무늬로 나옴**: 리본 케이블이 완전히 삽입되지 않았거나 뒤집혀 꽂힌 경우입니다. 전원을 끄고 다시 연결하세요.
- **torch 설치가 너무 느리거나 실패함**: `--extra-index-url https://www.piwheels.org/simple` 옵션으로 재시도하세요 (ARM용 사전 빌드 wheel 제공).
- **펌프가 반응 없음**: `tools/test_pump.py` 로 GPIO 신호만 단독 테스트 → 릴레이 LED가 켜지는지 확인 → `pump.active_high` 값을 반대로 바꿔보세요.
- **모델 로드 에러**: 에러 메시지에 `model.type` 을 어떻게 바꿔야 하는지 안내 문구가 함께 출력됩니다. `state_dict` 방식이라면 `models/architecture.py` 작성이 필요합니다.
- **오탐이 너무 많음/적음**: `config.yaml` 의 `detection` 섹션 값을 조정하세요.

---

## 11. 안전 주의사항

- 펌프와 전자 회로가 물(분사액)에 직접 닿지 않도록 방수 처리하세요.
- 라즈베리파이와 카메라 리본 케이블, 릴레이는 습기가 있는 벽면 근처에 직접 노출하지 마세요.
- 장시간 무인 운영 시 `pump.max_run_seconds` 를 반드시 짧게 설정해 오작동으로 인한 누수/과분사를 방지하세요.
