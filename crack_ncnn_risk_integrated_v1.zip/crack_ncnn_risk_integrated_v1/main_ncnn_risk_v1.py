"""
NCNN crack segmentation -> physical crack measurement -> risk assessment -> pump.

Run examples:
  python main_ncnn_risk_v1.py --source picam --headless
  python main_ncnn_risk_v1.py --source 0
  python main_ncnn_risk_v1.py --source sample_images/wall_diagonal_crack.jpg
"""
import argparse
import time
import yaml
import cv2

from src.camera import FrameSource
from src.alert import AlertLogger
from src.ncnn_seg_detector_v1 import NcnnCrackSegmenter
from src.crack_measurement_v1 import measure_cracks_from_mask
from src.risk_engine_mm_v1 import RiskEngineMM
from src.pump_controller_v1 import PumpController
from src.visualizer_mm_v1 import draw_overlay_mm


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def main():
    parser = argparse.ArgumentParser(description="NCNN crack risk + pump integrated runner")
    parser.add_argument("--source", default=None,
                        help="0=USB webcam, picam=Raspberry Pi CSI, or image/video path")
    parser.add_argument("--config", default="config_ncnn_risk_v1.yaml")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--save-video", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    source = args.source if args.source is not None else cfg["camera"]["source"]

    cam = FrameSource(source, cfg["camera"]["width"], cfg["camera"]["height"])
    segmenter = NcnnCrackSegmenter(cfg)
    engine = RiskEngineMM(cfg)
    alert = AlertLogger(cfg)
    pump = PumpController(cfg)

    cal = cfg["calibration"]
    if not cal.get("ready", False):
        print("[WARN] calibration.ready=false")
        print("[WARN] mm values are PREVIEW ONLY until mm_per_px is calibrated at the fixed camera-wall distance.")
        print("[WARN] Hardware spray is automatically blocked while calibration.ready=false.")

    writer = None
    frame_idx = 0
    frame_skip = max(int(cfg["camera"].get("frame_skip", 1)), 1)
    last_mask = None
    last_features = []
    last_infer_ms = 0.0
    prev_t = time.time()
    fps = 0.0

    print("[INFO] NCNN crack risk system started. Press q to quit when display is enabled.")

    try:
        while True:
            ok, frame = cam.read()
            if not ok or frame is None:
                print("[INFO] No more frames. Exiting.")
                break

            if frame_idx % frame_skip == 0:
                t0 = time.perf_counter()
                last_mask = segmenter.predict_mask(frame)
                last_infer_ms = (time.perf_counter() - t0) * 1000.0

                last_features = measure_cracks_from_mask(
                    last_mask,
                    mm_per_px=float(cal["mm_per_px"]),
                    cfg=cfg["measurement"],
                )
            frame_idx += 1

            raw_score, severities, diagnostics = engine.compute_frame_score(last_features, frame.shape)

            if cam.is_static_image():
                for _ in range(int(cfg["temporal_smoothing"]["history_len"])):
                    smoothed_score, level = engine.update(raw_score)
            else:
                smoothed_score, level = engine.update(raw_score)

            max_width_mm = max((f.get("width_mm", 0.0) for f in last_features), default=0.0)
            should_spray = engine.should_spray(
                last_features,
                level,
                calibration_ready=bool(cal.get("ready", False)),
            )
            pump.update(should_spray, max_width_mm=max_width_mm, level=level)

            now = time.time()
            fps = 0.9 * fps + 0.1 * (1.0 / max(now - prev_t, 1e-6))
            prev_t = now

            vis = draw_overlay_mm(
                frame.copy(),
                last_features,
                smoothed_score,
                level,
                fps=fps,
                infer_ms=last_infer_ms,
                calibration_ready=bool(cal.get("ready", False)),
            )
            alert.maybe_alert(frame, smoothed_score, level)

            if args.save_video:
                if writer is None:
                    h, w = vis.shape[:2]
                    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                    writer = cv2.VideoWriter(args.save_video, fourcc, 15, (w, h))
                writer.write(vis)

            if not args.headless:
                cv2.imshow("NCNN Building Crack Risk", vis)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            else:
                print(
                    f"[frame {frame_idx}] infer={last_infer_ms:.0f}ms "
                    f"score={smoothed_score:.1f} level={level} fps={fps:.1f} "
                    f"cracks={len(last_features)} maxW={max_width_mm:.3f}mm "
                    f"coverage={diagnostics['coverage_ratio']*100:.3f}% "
                    f"spray_request={should_spray}"
                )

            if cam.is_static_image():
                if not args.headless:
                    cv2.waitKey(0)
                break

    except KeyboardInterrupt:
        print("\n[INFO] Interrupted by user.")
    finally:
        pump.close()
        cam.release()
        if writer is not None:
            writer.release()
        if not args.headless:
            cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
