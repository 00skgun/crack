import time


class PumpController:
    """GPIO pump wrapper with dry-run, consecutive-frame gating, and cooldown."""

    def __init__(self, cfg):
        pc = cfg["pump"]
        self.enabled = bool(pc.get("enabled", False))
        self.dry_run = bool(pc.get("dry_run", True))
        self.pin_in3 = int(pc.get("pin_in3", 17))
        self.pin_in4 = int(pc.get("pin_in4", 27))
        self.duration = float(pc.get("duration_sec", 2.0))
        self.cooldown = float(pc.get("cooldown_sec", 5.0))
        self.required_consecutive = max(int(pc.get("required_consecutive_analyzed_frames", 2)), 1)
        self._consecutive = 0
        self._last_spray_ts = -1e9
        self.in3 = None
        self.in4 = None

        if self.enabled and not self.dry_run:
            from gpiozero import DigitalOutputDevice
            self.in3 = DigitalOutputDevice(self.pin_in3)
            self.in4 = DigitalOutputDevice(self.pin_in4)
            self.stop()
            print(f"[INFO] Pump GPIO ready: IN3={self.pin_in3}, IN4={self.pin_in4}")
        elif self.enabled:
            print("[INFO] Pump DRY-RUN enabled: no GPIO will be activated.")
        else:
            print("[INFO] Pump disabled in config.")

    def stop(self):
        if self.in3 is not None:
            self.in3.off()
        if self.in4 is not None:
            self.in4.off()

    def _spray(self):
        if not self.enabled:
            return
        if self.dry_run:
            print(f"[PUMP DRY-RUN] spray {self.duration:.1f}s")
            return

        print(f"[PUMP] ON for {self.duration:.1f}s")
        self.in3.on()
        self.in4.off()
        time.sleep(self.duration)
        self.stop()
        print("[PUMP] OFF")

    def update(self, request, max_width_mm=0.0, level=""):
        if request:
            self._consecutive += 1
        else:
            self._consecutive = 0
            return False

        if self._consecutive < self.required_consecutive:
            return False

        now = time.monotonic()
        if now - self._last_spray_ts < self.cooldown:
            return False

        print(f"[SPRAY TRIGGER] level={level} max_width={max_width_mm:.3f}mm")
        self._spray()
        self._last_spray_ts = now
        self._consecutive = 0
        return True

    def close(self):
        self.stop()
        if self.in3 is not None:
            self.in3.close()
        if self.in4 is not None:
            self.in4.close()
