import cv2

LEVEL_COLORS = {
    "안전": (0, 200, 0),
    "주의": (0, 200, 255),
    "위험": (0, 140, 255),
    "심각": (0, 0, 255),
}
LEVEL_EN = {"안전": "SAFE", "주의": "CAUTION", "위험": "DANGER", "심각": "CRITICAL"}


def draw_overlay_mm(frame, features, score, level, fps=None, infer_ms=None, calibration_ready=True):
    color = LEVEL_COLORS.get(level, (255, 255, 255))

    for i, f in enumerate(features):
        x, y, w, h = f["bbox"]
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
        label = (
            f"#{i} {f.get('orientation', '?')} "
            f"W={f.get('width_mm', 0.0):.3f}mm "
            f"L={f.get('length_mm', 0.0):.1f}mm"
        )
        cv2.putText(frame, label, (x, max(y - 6, 12)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, color, 1, cv2.LINE_AA)

    cv2.rectangle(frame, (0, 0), (frame.shape[1], 55), color, -1)
    status = f"RISK {LEVEL_EN.get(level, level)} score={score:.1f}/100 cracks={len(features)}"
    cv2.putText(frame, status, (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (0, 0, 0), 2, cv2.LINE_AA)

    perf = []
    if fps is not None:
        perf.append(f"FPS={fps:.1f}")
    if infer_ms is not None:
        perf.append(f"NCNN={infer_ms:.0f}ms")
    if not calibration_ready:
        perf.append("MM PREVIEW / PUMP BLOCKED")
    cv2.putText(frame, " | ".join(perf), (8, 45),
                cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 0, 0), 1, cv2.LINE_AA)
    return frame
