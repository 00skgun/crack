from collections import deque
import numpy as np

LEVEL_SAFE = "안전"
LEVEL_CAUTION = "주의"
LEVEL_DANGER = "위험"
LEVEL_CRITICAL = "심각"
_LEVEL_ORDER = [LEVEL_SAFE, LEVEL_CAUTION, LEVEL_DANGER, LEVEL_CRITICAL]


class RiskEngineMM:
    """
    Agreed risk design:
      per-crack severity = 65% width(mm) + 20% length(mm) + 15% orientation
      frame score = 70% max severity + 15% mean severity + 15% coverage/density proxy
      then EMA + hysteresis.
    """

    def __init__(self, cfg):
        rs = cfg["risk_scoring"]
        self.w_wid = float(rs["weights"]["width"])
        self.w_len = float(rs["weights"]["length"])
        self.w_ori = float(rs["weights"]["orientation"])
        self.orient_weight = rs["orientation_weight"]
        self.tiers = rs["width_tiers_mm"]
        self.length_reference_mm = float(rs["length_reference_mm"])
        self.combo = rs["frame_score_combo"]
        self.coverage_reference_ratio = float(rs.get("coverage_reference_ratio", 0.03))

        ts = cfg["temporal_smoothing"]
        self.alpha = float(ts["ema_alpha"])
        self.history = deque(maxlen=int(ts["history_len"]))
        self.hysteresis = ts["hysteresis"]

        lv = cfg["levels"]
        self.safe_max = float(lv["safe_max"])
        self.caution_max = float(lv["caution_max"])
        self.danger_max = float(lv["danger_max"])

        sp = cfg["spray_policy"]
        self.spray_min_width_mm = float(sp["min_width_mm"])
        self.spray_trigger_level = sp.get("trigger_level", LEVEL_DANGER)

        self._ema_score = 0.0
        self._current_level = LEVEL_SAFE

    def _width_norm(self, width_mm):
        """Continuous piecewise score using the agreed 0.1/0.3/0.5/1.0 mm tiers."""
        a = float(self.tiers["hairline"])
        b = float(self.tiers["action"])
        c = float(self.tiers["high"])
        d = float(self.tiers["critical"])
        x = max(float(width_mm), 0.0)

        # Anchors: 0 -> 0, 0.1 -> .20, 0.3 -> .50, 0.5 -> .75, 1.0 -> 1.0
        anchors_x = np.array([0.0, a, b, c, d], dtype=float)
        anchors_y = np.array([0.0, 0.20, 0.50, 0.75, 1.00], dtype=float)
        if x >= d:
            return 1.0
        return float(np.interp(x, anchors_x, anchors_y))

    def _defect_severity(self, feat):
        width_norm = self._width_norm(feat.get("width_mm", 0.0))
        length_norm = min(max(feat.get("length_mm", 0.0), 0.0) / self.length_reference_mm, 1.0)
        ori_w = float(self.orient_weight.get(feat.get("orientation", "unknown"), 0.4))

        severity = self.w_wid * width_norm + self.w_len * length_norm + self.w_ori * ori_w
        return float(np.clip(severity, 0.0, 1.0)) * 100.0

    def compute_frame_score(self, features, frame_shape):
        h, w = frame_shape[:2]
        frame_area = float(h * w)
        if not features:
            return 0.0, [], {"coverage_ratio": 0.0, "coverage_score": 0.0}

        severities = [self._defect_severity(f) for f in features]
        coverage_ratio = min(sum(float(f.get("area_px", 0.0)) for f in features) / frame_area, 1.0)
        coverage_score = min(coverage_ratio / max(self.coverage_reference_ratio, 1e-9), 1.0) * 100.0

        raw = (
            float(self.combo["max_w"]) * max(severities)
            + float(self.combo["mean_w"]) * (sum(severities) / len(severities))
            + float(self.combo["coverage_w"]) * coverage_score
        )
        diagnostics = {
            "coverage_ratio": coverage_ratio,
            "coverage_score": coverage_score,
            "max_severity": max(severities),
            "mean_severity": sum(severities) / len(severities),
        }
        return float(np.clip(raw, 0.0, 100.0)), severities, diagnostics

    def update(self, raw_score):
        self._ema_score = self.alpha * raw_score + (1.0 - self.alpha) * self._ema_score
        self.history.append(self._ema_score)
        self._current_level = self._level_from_score(self._ema_score, self._current_level)
        return self._ema_score, self._current_level

    def _target_level(self, score):
        if score <= self.safe_max:
            return LEVEL_SAFE
        if score <= self.caution_max:
            return LEVEL_CAUTION
        if score <= self.danger_max:
            return LEVEL_DANGER
        return LEVEL_CRITICAL

    def _level_from_score(self, score, prev_level):
        target = self._target_level(score)
        if _LEVEL_ORDER.index(target) >= _LEVEL_ORDER.index(prev_level):
            return target

        down_margin = float(self.hysteresis.get("down_margin", 0.0))
        target_down = self._target_level(score + down_margin)
        if _LEVEL_ORDER.index(target_down) < _LEVEL_ORDER.index(prev_level):
            return target_down
        return prev_level

    def should_spray(self, features, level, calibration_ready):
        if not calibration_ready or not features:
            return False
        max_width = max(float(f.get("width_mm", 0.0)) for f in features)
        if max_width < self.spray_min_width_mm:
            return False
        try:
            return _LEVEL_ORDER.index(level) >= _LEVEL_ORDER.index(self.spray_trigger_level)
        except ValueError:
            return level in (LEVEL_DANGER, LEVEL_CRITICAL)
