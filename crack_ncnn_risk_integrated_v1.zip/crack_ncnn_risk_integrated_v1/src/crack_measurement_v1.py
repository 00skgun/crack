import math
import cv2
import numpy as np


def _morphological_skeleton(binary_u8):
    img = (binary_u8 > 0).astype(np.uint8) * 255
    skel = np.zeros_like(img)
    element = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))

    # Binary mask is at most the camera frame size; safe fallback when ximgproc is unavailable.
    while cv2.countNonZero(img) > 0:
        eroded = cv2.erode(img, element)
        opened = cv2.dilate(eroded, element)
        skel = cv2.bitwise_or(skel, cv2.subtract(img, opened))
        img = eroded
    return skel


def _skeletonize(binary_u8):
    # OpenCV contrib thinning is much faster when installed.
    try:
        if hasattr(cv2, "ximgproc") and hasattr(cv2.ximgproc, "thinning"):
            return cv2.ximgproc.thinning((binary_u8 > 0).astype(np.uint8) * 255)
    except Exception:
        pass
    return _morphological_skeleton(binary_u8)


def _skeleton_length_px(skel_u8):
    s = skel_u8 > 0
    # Count each undirected edge once: right, down, down-right, down-left.
    horizontal = np.count_nonzero(s[:, :-1] & s[:, 1:])
    vertical = np.count_nonzero(s[:-1, :] & s[1:, :])
    diag1 = np.count_nonzero(s[:-1, :-1] & s[1:, 1:])
    diag2 = np.count_nonzero(s[:-1, 1:] & s[1:, :-1])
    return float(horizontal + vertical + math.sqrt(2.0) * (diag1 + diag2))


def _endpoint_count(skel_u8):
    """Count connected endpoint pixels (degree 1). More stable than raw branch-pixel counts."""
    s = (skel_u8 > 0).astype(np.uint8)
    if not np.any(s):
        return 0
    kernel = np.ones((3, 3), dtype=np.uint8)
    neighbors = cv2.filter2D(s, -1, kernel, borderType=cv2.BORDER_CONSTANT) - s
    endpoint_mask = ((s > 0) & (neighbors == 1)).astype(np.uint8) * 255
    n, _, _, _ = cv2.connectedComponentsWithStats(endpoint_mask, connectivity=8)
    return max(int(n) - 1, 0)


def _orientation_from_skeleton(skel_u8, cfg):
    ys, xs = np.where(skel_u8 > 0)
    if len(xs) < 2:
        return "unknown", 0.0

    pts = np.column_stack([xs.astype(np.float32), ys.astype(np.float32)])
    pts -= pts.mean(axis=0, keepdims=True)
    cov = np.cov(pts, rowvar=False)
    vals, vecs = np.linalg.eigh(cov)
    principal = vecs[:, int(np.argmax(vals))]

    angle = abs(math.degrees(math.atan2(float(principal[1]), float(principal[0]))))
    if angle > 90.0:
        angle = 180.0 - angle

    h_deg = float(cfg.get("orientation_horizontal_deg", 22.5))
    v_deg = float(cfg.get("orientation_vertical_deg", 67.5))
    if angle <= h_deg:
        orientation = "horizontal"
    elif angle >= v_deg:
        orientation = "vertical"
    else:
        orientation = "diagonal"
    return orientation, angle


def measure_cracks_from_mask(mask_u8, mm_per_px, cfg):
    """Convert a full-frame binary crack mask to per-crack physical features."""
    binary = (mask_u8 > 0).astype(np.uint8) * 255

    close_k = int(cfg.get("close_kernel", 0))
    close_iter = int(cfg.get("close_iterations", 1))
    if close_k >= 3:
        if close_k % 2 == 0:
            close_k += 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close_k, close_k))
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=close_iter)

    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    min_area = int(cfg.get("min_component_area_px", 20))
    pctl = float(cfg.get("width_percentile", 95.0))
    branch_min_endpoints = int(cfg.get("branch_min_endpoints", 4))

    features = []
    for label in range(1, n):
        area_px = int(stats[label, cv2.CC_STAT_AREA])
        if area_px < min_area:
            continue

        x = int(stats[label, cv2.CC_STAT_LEFT])
        y = int(stats[label, cv2.CC_STAT_TOP])
        w = int(stats[label, cv2.CC_STAT_WIDTH])
        h = int(stats[label, cv2.CC_STAT_HEIGHT])

        component = (labels == label).astype(np.uint8) * 255
        skel = _skeletonize(component)
        dist = cv2.distanceTransform(component, cv2.DIST_L2, 5)

        sy, sx = np.where(skel > 0)
        if len(sx):
            local_widths = 2.0 * dist[sy, sx]
            width_px = float(np.percentile(local_widths, pctl))
            max_width_px = float(np.max(local_widths))
        else:
            width_px = 0.0
            max_width_px = 0.0

        length_px = _skeleton_length_px(skel)
        endpoint_count = _endpoint_count(skel)
        orientation, angle_deg = _orientation_from_skeleton(skel, cfg)
        if endpoint_count >= branch_min_endpoints:
            orientation = "branching"

        features.append({
            "bbox": (x, y, w, h),
            "area_px": area_px,
            "area_mm2": float(area_px) * float(mm_per_px) ** 2,
            "length_px": length_px,
            "length_mm": length_px * float(mm_per_px),
            "width_px": width_px,
            "width_mm": width_px * float(mm_per_px),
            "max_width_px": max_width_px,
            "max_width_mm": max_width_px * float(mm_per_px),
            "orientation": orientation,
            "angle_deg": angle_deg,
            "endpoint_count": endpoint_count,
        })

    # Most concerning crack first.
    features.sort(key=lambda f: (f["width_mm"], f["length_mm"]), reverse=True)
    return features
