import cv2
import numpy as np
import ncnn


class NcnnCrackSegmenter:
    """NCNN wrapper for the converted DeepLabV3 crack segmentation model."""

    def __init__(self, cfg):
        mc = cfg["ncnn_model"]
        self.input_blob = mc.get("input_blob", "in0")
        self.output_blob = mc.get("output_blob", "out0")
        self.in_w = int(mc.get("input_width", 256))
        self.in_h = int(mc.get("input_height", 256))
        self.output_is_logits = bool(mc.get("output_is_logits", True))
        self.prob_threshold = float(mc.get("probability_threshold", 0.5))

        self.net = ncnn.Net()
        self.net.opt.num_threads = int(mc.get("num_threads", 4))
        self.net.opt.use_packing_layout = True

        ret_p = self.net.load_param(mc["param_path"])
        ret_b = self.net.load_model(mc["bin_path"])
        if ret_p != 0:
            raise RuntimeError(f"NCNN load_param failed ({ret_p}): {mc['param_path']}")
        if ret_b != 0:
            raise RuntimeError(f"NCNN load_model failed ({ret_b}): {mc['bin_path']}")

        print(f"[INFO] NCNN loaded: {mc['param_path']} + {mc['bin_path']}")
        print(f"[INFO] blobs: {self.input_blob} -> {self.output_blob}, input={self.in_w}x{self.in_h}")

    @staticmethod
    def _sigmoid(x):
        x = np.clip(x, -50.0, 50.0)
        return 1.0 / (1.0 + np.exp(-x))

    def predict_mask(self, frame_bgr):
        """
        Returns uint8 0/255 mask resized back to the ORIGINAL frame geometry.
        This matters because mm_per_px calibration is defined on the original camera frame.
        """
        orig_h, orig_w = frame_bgr.shape[:2]

        resized = cv2.resize(frame_bgr, (self.in_w, self.in_h), interpolation=cv2.INTER_LINEAR)
        mat_in = ncnn.Mat.from_pixels(
            resized,
            ncnn.Mat.PixelType.PIXEL_BGR2RGB,
            self.in_w,
            self.in_h,
        )
        mat_in.substract_mean_normalize(
            [0.0, 0.0, 0.0],
            [1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0],
        )

        ex = self.net.create_extractor()
        ret = ex.input(self.input_blob, mat_in)
        if ret != 0:
            raise RuntimeError(f"NCNN input failed: ret={ret}, blob={self.input_blob}")

        ret, mat_out = ex.extract(self.output_blob)
        if ret != 0:
            raise RuntimeError(f"NCNN extract failed: ret={ret}, blob={self.output_blob}")

        arr = np.asarray(mat_out, dtype=np.float32)
        arr = np.squeeze(arr)
        if arr.size != self.in_w * self.in_h:
            raise RuntimeError(f"Unexpected NCNN output shape={arr.shape}, size={arr.size}")
        arr = arr.reshape(self.in_h, self.in_w)

        if self.output_is_logits:
            prob = self._sigmoid(arr)
        else:
            prob = arr

        mask_small = (prob >= self.prob_threshold).astype(np.uint8) * 255

        # Restore original camera geometry before physical measurement.
        mask_full = cv2.resize(mask_small, (orig_w, orig_h), interpolation=cv2.INTER_NEAREST)
        return mask_full
