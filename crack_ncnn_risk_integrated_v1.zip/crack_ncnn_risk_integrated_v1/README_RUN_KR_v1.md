# NCNN + mm 기반 균열 위험도 + 펌프 통합 v1

## 이 버전에서 바뀐 것
기존 `amugeona3.py`의 **화면 균열 면적 3% 이상 -> 펌프 ON** 규칙은 사용하지 않습니다.

이 버전은 아래 순서입니다.

1. NCNN DeepLabV3 segmentation
2. binary crack mask를 원본 카메라 해상도로 복원
3. connected component로 균열 분리
4. skeleton + distance transform
5. 대표 폭 = skeleton local width의 P95
6. 고정거리 calibration의 `mm_per_px`로 mm 변환
7. 개별 severity = width 65% + length 20% + orientation 15%
8. frame risk = max 70% + mean 15% + coverage 15%
9. 기존 방식과 같은 EMA + hysteresis
10. `width >= 0.3 mm` 이고 위험 등급 이상일 때 spray request
11. 연속 2회 + cooldown 후 펌프 작동

`0.3 mm`는 구조물 붕괴 판정값이 아니라 이 prototype의 조치/분사 기준입니다.

---

## 기존 프로젝트에 복사할 파일
현재 실행 루트:

```bash
cd ~/Desktop/0901_test_3/crack/files/building_risk_drone/building_risk_drone
```

ZIP 안 파일을 다음처럼 둡니다.

```text
building_risk_drone/
├── main_ncnn_risk_v1.py
├── config_ncnn_risk_v1.yaml
├── requirements_ncnn_risk_v1.txt
├── models/
│   └── esw_seg_ncnn/
│       ├── crackseg.ncnn.param   # 본인이 변환한 파일
│       └── crackseg.ncnn.bin     # 본인이 변환한 파일
└── src/
    ├── camera.py                 # 기존 그대로
    ├── alert.py                  # 기존 그대로
    ├── ncnn_seg_detector_v1.py   # 새 파일
    ├── crack_measurement_v1.py   # 새 파일
    ├── risk_engine_mm_v1.py      # 새 파일
    ├── pump_controller_v1.py     # 새 파일
    └── visualizer_mm_v1.py       # 새 파일
```

기존 `main.py`, `risk_engine.py`, `yolo_detector.py`는 삭제하지 않습니다.

---

## NCNN 모델 복사
먼저 모델 폴더 생성:

```bash
mkdir -p models/esw_seg_ncnn
```

본인이 변환한 파일이 예를 들어 현재 다른 폴더에 있다면:

```bash
cp /원래/경로/crackseg.ncnn.param models/esw_seg_ncnn/
cp /원래/경로/crackseg.ncnn.bin models/esw_seg_ncnn/
```

확인:

```bash
ls -lh models/esw_seg_ncnn
```

---

## 패키지 확인
venv를 켠 상태에서:

```bash
python -c "import ncnn, cv2, numpy, yaml; print('OK')"
```

GPIO까지 실제 사용할 때:

```bash
python -c "import gpiozero; print('GPIOZERO OK')"
```

---

## 첫 실행: 펌프는 반드시 dry-run
`config_ncnn_risk_v1.yaml` 기본값은:

```yaml
calibration:
  ready: false
  mm_per_px: 0.050

pump:
  enabled: true
  dry_run: true
```

즉 모델/위험도는 돌아가지만 실제 GPIO는 켜지지 않습니다.

CSI 카메라:

```bash
python main_ncnn_risk_v1.py --source picam --headless
```

화면을 볼 수 있다면:

```bash
python main_ncnn_risk_v1.py --source picam
```

USB 카메라:

```bash
python main_ncnn_risk_v1.py --source 0
```

---

## mm calibration 후 반드시 바꿀 값
고정거리 장치에서 실제로 측정한 값이 예를 들어 `1 px = 0.043 mm`라면:

```yaml
calibration:
  ready: true
  mm_per_px: 0.043
```

**0.050은 예시값일 뿐입니다.** 실제 분사 전에 반드시 바꿉니다.

---

## 실제 펌프를 켤 때
mask, 폭(mm), 위험도, threshold가 정상인지 먼저 확인한 다음:

```yaml
pump:
  enabled: true
  dry_run: false
```

현재 `amugeona3.py`와 동일하게 BCM GPIO 17/27을 사용합니다.

---

## 속도가 너무 느리면
Pi 4B에서 DeepLabV3-ResNet101은 NCNN이어도 무거울 수 있습니다.

먼저:

```yaml
camera:
  frame_skip: 3
```

또는 4로 올립니다. 화면 capture는 계속되지만 NCNN inference만 N frame마다 수행됩니다.

터미널에 매번 `NCNN=xxxms`가 출력되므로 실제 병목을 바로 확인할 수 있습니다.

---

## 주의: 기존 amugeona3.py와 다른 출력 threshold
DeepLabV3의 표준 출력은 logits입니다. 그래서 이 버전은:

```text
logit -> sigmoid -> probability >= 0.5
```

을 기본으로 사용합니다.

만약 본인이 변환한 NCNN 모델 자체에 sigmoid가 이미 포함되어 있다면 config에서:

```yaml
ncnn_model:
  output_is_logits: false
```

로 변경합니다.
